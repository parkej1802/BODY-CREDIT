// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Lootable_Base.h"
#include "Lootable_Box.generated.h"

/**
 * 
 */
UCLASS()
class BODYCREDIT_API ALootable_Box : public ALootable_Base
{
	GENERATED_BODY()
	
};
