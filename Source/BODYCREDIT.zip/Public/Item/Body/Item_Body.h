// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Item/Item_Base.h"
#include "Item_Body.generated.h"

/**
 * 
 */
UCLASS()
class BODYCREDIT_API AItem_Body : public AItem_Base
{
	GENERATED_BODY()
	
};
