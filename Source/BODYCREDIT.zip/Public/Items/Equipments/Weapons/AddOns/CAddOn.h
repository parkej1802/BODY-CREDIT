﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CAddOn.generated.h"

UCLASS()
class BODYCREDIT_API ACAddOn : public AActor
{
	GENERATED_BODY()



};
