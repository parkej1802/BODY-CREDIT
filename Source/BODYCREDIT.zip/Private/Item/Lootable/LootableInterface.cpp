// Fill out your copyright notice in the Description page of Project Settings.


#include "Item/Lootable/LootableInterface.h"

// Add default functionality here for any ILootableInterface functions that are not pure virtual.
