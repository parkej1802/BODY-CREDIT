﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Item/Head/Item_Head.h"

AItem_Head::AItem_Head()
{
	Width = 3;
	Height = 3;
}
