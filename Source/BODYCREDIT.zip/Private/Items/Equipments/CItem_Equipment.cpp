﻿#include "Items/Equipments/CItem_Equipment.h"
#include "Global.h"

ACItem_Equipment::ACItem_Equipment()
{
	PrimaryActorTick.bCanEverTick = true;

}

void ACItem_Equipment::BeginPlay()
{
	Super::BeginPlay();

}

void ACItem_Equipment::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}
