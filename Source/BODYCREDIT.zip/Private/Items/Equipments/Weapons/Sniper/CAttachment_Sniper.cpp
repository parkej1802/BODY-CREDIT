﻿#include "Items/Equipments/Weapons/Sniper/CAttachment_Sniper.h"
#include "Global.h"
#include "Components/SkeletalMeshComponent.h"
#include "Characters/CNox.h"
#include "Components/ShapeComponent.h"

ACAttachment_Sniper::ACAttachment_Sniper()
{
	PrimaryActorTick.bCanEverTick = true;

}

void ACAttachment_Sniper::BeginPlay()
{
	Super::BeginPlay();

}

void ACAttachment_Sniper::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}