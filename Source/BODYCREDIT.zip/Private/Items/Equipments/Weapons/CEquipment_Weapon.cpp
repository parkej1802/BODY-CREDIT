﻿#include "Items/Equipments/Weapons/CEquipment_Weapon.h"
#include "Global.h"

ACEquipment_Weapon::ACEquipment_Weapon()
{
	PrimaryActorTick.bCanEverTick = true;

}

void ACEquipment_Weapon::BeginPlay()
{
	Super::BeginPlay();

}

void ACEquipment_Weapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}
