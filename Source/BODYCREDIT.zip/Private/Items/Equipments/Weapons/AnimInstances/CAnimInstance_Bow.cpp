﻿#include "Items/Equipments/Weapons/AnimInstances/CAnimInstance_Bow.h"
#include "Global.h"

void UCAnimInstance_Bow::NativeBeginPlay()
{
	Super::NativeBeginPlay();

}

void UCAnimInstance_Bow::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

}
